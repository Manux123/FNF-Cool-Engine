package funkin.menus;

#if desktop
import data.Discord.DiscordClient;
#end
import flash.text.TextField;
import flixel.FlxG;
import lime.app.Application;
import flixel.FlxSprite;
import flixel.addons.display.FlxGridOverlay;
import flixel.addons.transition.FlxTransitionableState;
import flixel.util.FlxTimer;
import funkin.transitions.StateTransition;
import flixel.group.FlxGroup.FlxTypedGroup;
import flixel.math.FlxMath;
import flixel.tweens.FlxEase;
import funkin.menus.StoryMenuState;
import flixel.text.FlxText;
import flixel.util.FlxColor;
import flixel.tweens.FlxTween;
import lime.utils.Assets;
import flixel.sound.FlxSound;
import openfl.utils.Assets as OpenFlAssets;
import flixel.effects.particles.FlxEmitter;
import funkin.states.LoadingState;
import flixel.effects.particles.FlxParticle;
import funkin.gameplay.objects.character.HealthIcon;
import funkin.data.Song;
import funkin.gameplay.objects.hud.Highscore;
import funkin.scripting.StateScriptHandler;
import funkin.transitions.StickerTransition;
import funkin.menus.StoryMenuState.Songs;
import funkin.gameplay.PlayState;
import funkin.data.Conductor;
import funkin.data.CoolUtil;
import ui.Alphabet;

using StringTools;

import haxe.Json;
import haxe.format.JsonParser;
#if sys
import sys.FileSystem;
#end

class FreeplayState extends funkin.states.MusicBeatState
{
	var toBeFinished = 0;
	var finished = 0;

	public static var songInfo:Songs;

	var songs:Array<SongMetadata> = [];

	var selector:FlxText;
	var discSpr:FlxSprite;

	private static var curSelected:Int = 0;
	private static var curDifficulty:Int = 1;

	var scoreBG:FlxSprite;
	var scoreText:FlxText;
	var diffText:FlxText;
	var lerpScore:Int = 0;
	var lerpRating:Float = 0;
	var intendedScore:Int = 0;
	var intendedRating:Float = 0;
	var songText:Alphabet;

	private var grpSongs:FlxTypedGroup<Alphabet>;
	private var curPlaying:Bool = false;

	private var iconArray:Array<HealthIcon> = [];

	public static var coolColors:Array<Int> = [];

	var bg:FlxSprite;
	var bgGradient:FlxSprite;
	var intendedColor:Int;
	var colorTween:FlxTween;

	// Error message
	var errorText:FlxText;
	var errorTween:FlxTween;

	// Nuevas variables para efectos visuales
	var particleEmitter:FlxEmitter;
	var screenBumpAmount:Float = 0;
	var bpmTarget:Float = 0;
	var beatTimer:Float = 0;
	var visualBars:FlxTypedGroup<FlxSprite>;
	var glowOverlay:FlxSprite;

	// Variables para el screen shake/bump al ritmo
	var camBumpIntensity:Float = 1.0;
	var lastScreenBumpBeat:Int = -1;

	override function create()
	{
		FlxG.mouse.visible = false;

		// ✅ FIX: Limpiar inputs al inicio para evitar inputs residuales del state anterior
		FlxG.keys.reset();

		if (StickerTransition.enabled)
		{
			transIn = null;
			transOut = null;
		}

		MainMenuState.musicFreakyisPlaying = false;
		if (vocals == null)
		{
			final snd = Paths.loadMusic('girlfriendsRingtone/girlfriendsRingtone');
			if (snd != null) FlxG.sound.playMusic(snd, 0.7);
			else FlxG.sound.playMusic(Paths.music('girlfriendsRingtone/girlfriendsRingtone'), 0.7);
		}

		// Error message text
		errorText = new FlxText(0, FlxG.height * 0.5 - 50, FlxG.width, "", 32);
		errorText.setFormat(Paths.font("vcr.ttf"), 32, FlxColor.RED, CENTER, FlxTextBorderStyle.OUTLINE, FlxColor.BLACK);
		errorText.setBorderStyle(OUTLINE, FlxColor.BLACK, 4);
		errorText.scrollFactor.set();
		errorText.alpha = 0;

		loadSongsData();
		if (songInfo != null)
		{
			songsSystem();
		}
		else
		{
			songInfo = null;
		}

		#if desktop
		DiscordClient.changePresence("In the FreePlay", null);
		#end

		// === FONDO MEJORADO CON DEGRADADO ===
		bg = new FlxSprite();
		if (Paths.image('menu/menuDesat') != null)
		{
			bg.loadGraphic(Paths.image('menu/menuDesat'));
		}
		else
		{
			// Fallback: crear un fondo sólido si no existe la imagen
			bg.makeGraphic(FlxG.width, FlxG.height, 0xFF2A2A2A);
		}
		bg.color = 0xFF2A2A2A;
		bg.scrollFactor.set(0.1, 0.1);
		add(bg);

		// Degradado overlay para dar profundidad
		bgGradient = new FlxSprite();
		bgGradient.makeGraphic(FlxG.width, FlxG.height, FlxColor.TRANSPARENT, true);
		bgGradient.pixels.lock();   // requerido en native cpp antes de operaciones pixel
		for (i in 0...FlxG.height)
		{
			var ratio:Float = i / FlxG.height;
			var alpha:Int = Std.int(ratio * 0x88);
			bgGradient.pixels.fillRect(new flash.geom.Rectangle(0, i, FlxG.width, 1), alpha << 24);
		}
		bgGradient.pixels.unlock();
		add(bgGradient);

		// === BARRAS VISUALES DE AUDIO (decorativas) ===
		visualBars = new FlxTypedGroup<FlxSprite>();
		add(visualBars);

		for (i in 0...10)
		{
			var bar:FlxSprite = new FlxSprite(0 + (i * 140), FlxG.height - 150 + 100);
			bar.makeGraphic(120, 220, FlxColor.fromRGB(100 + i * 15, 150, 255 - i * 15));
			bar.alpha = 0.3;
			bar.scrollFactor.set();
			visualBars.add(bar);
		}

		// === SISTEMA DE PARTÍCULAS ===
		particleEmitter = new FlxEmitter(0, 0, 50);
		particleEmitter.makeParticles(2, 2, FlxColor.WHITE, 50);
		particleEmitter.launchMode = FlxEmitterMode.SQUARE;
		particleEmitter.velocity.set(-50, -100, 50, -200);
		particleEmitter.lifespan.set(3, 6);
		particleEmitter.alpha.set(0.4, 0.8, 0, 0);
		particleEmitter.scale.set(1, 1, 0.5, 0.5);
		particleEmitter.width = FlxG.width;
		particleEmitter.y = FlxG.height;
		add(particleEmitter);
		particleEmitter.start(false, 0.1);

		grpSongs = new FlxTypedGroup<Alphabet>();
		add(grpSongs);

		for (i in 0...songs.length)
		{
			songText = new Alphabet(0, (70 * i) + 30, songs[i].songName, true, false);
			songText.isMenuItem = true;
			songText.targetY = i;
			grpSongs.add(songText);

			var icon:HealthIcon = new HealthIcon(songs[i].songCharacter);
			icon.sprTracker = songText;

			// CORRECCIÓN: Verificar que el icono se creó correctamente antes de agregarlo
			if (icon != null)
			{
				iconArray.push(icon);
				add(icon);
			}
		}

		#if HSCRIPT_ALLOWED
		StateScriptHandler.init();
		StateScriptHandler.loadStateScripts('FreeplayState', this);
		StateScriptHandler.callOnScripts('onCreate', []);
		#end

		// === OVERLAY DE GLOW PARA EFECTOS ===
		glowOverlay = new FlxSprite();
		glowOverlay.makeGraphic(FlxG.width, FlxG.height, FlxColor.WHITE);
		glowOverlay.alpha = 0;
		glowOverlay.blend = ADD;
		add(glowOverlay);

		// === UI MEJORADA ===
		scoreBG = new FlxSprite(FlxG.width * 0.65, 30);
		scoreBG.makeGraphic(1, 95, 0xFF000000);
		scoreBG.alpha = 0.7;
		add(scoreBG);

		scoreText = new FlxText(FlxG.width * 0.66, 45, 0, "", 28);
		scoreText.setFormat(Paths.font("vcr.ttf"), 28, FlxColor.WHITE, RIGHT);
		scoreText.setBorderStyle(OUTLINE, FlxColor.BLACK, 2);
		add(scoreText);

		diffText = new FlxText(FlxG.width * 0.66, 85, 0, "", 24);
		diffText.setFormat(Paths.font("vcr.ttf"), 24, FlxColor.CYAN, RIGHT);
		diffText.setBorderStyle(OUTLINE, FlxColor.BLACK, 2);
		add(diffText);

		var ratingText:FlxText = new FlxText(FlxG.width * 0.66, 115, 0, "", 20);
		ratingText.setFormat(Paths.font("vcr.ttf"), 20, FlxColor.YELLOW, RIGHT);
		ratingText.setBorderStyle(OUTLINE, FlxColor.BLACK, 2);
		add(ratingText);

		if (songs.length > 0)
		{
			bg.color = songs[curSelected].color;
			intendedColor = bg.color;
		}
		else
		{
			bg.color = 0xFF2A2A2A;
			intendedColor = 0xFF2A2A2A;
		}
		changeSelection(0);

		// Auto-detectar dificultades del primer song seleccionado
		_updateDifficultyStuff();
		changeDiff();

		// === TEXTO INFERIOR MEJORADO ===
		var textBG:FlxSprite = new FlxSprite(0, FlxG.height - 30);
		textBG.makeGraphic(FlxG.width, 30, 0xFF000000);
		textBG.alpha = 0.8;
		add(textBG);

		StickerTransition.clearStickers();

		var leText:FlxText = new FlxText(0, FlxG.height - 26, FlxG.width, "SPACE: Preview Song | ENTER: Play | ESC: Back | E: Editor", 16);
		leText.scrollFactor.set();
		leText.setFormat('VCR OSD Mono', 16, FlxColor.WHITE, CENTER, FlxTextBorderStyle.OUTLINE, FlxColor.BLACK);
		add(leText);

		var versionShit:FlxText = new FlxText(12, FlxG.height - 26, 0, "FNF Cool Engine v" + Application.current.meta.get('version'), 12);
		versionShit.scrollFactor.set();
		versionShit.setFormat("VCR OSD Mono", 16, FlxColor.CYAN, LEFT, FlxTextBorderStyle.OUTLINE, FlxColor.BLACK);
		add(versionShit);

		errorText.visible = false;
		add(errorText);

		if (songs.length == 0)
		{
			showError("No songs found!\nPlease add songs to your songList.json");
			
			// ✅ FIX: Abrir automáticamente el editor si no hay canciones
			// Esperar un momento para que el mensaje de error sea visible primero
			new FlxTimer().start(2.0, function(_) {
				if (funkin.menus.MainMenuState.developerMode)
				{
					StateTransition.switchState(new FreeplayEditorState());
				}
				else
				{
					// Si el modo desarrollador no está activo, mostrar un mensaje adicional
					showError("No songs found!\n\nEnable Developer Mode in Mod Menu\nSection ''System'' to use the Freeplay Editor");
				}
			});
		}

		// Animación de entrada
		FlxTween.tween(bg, {alpha: 1, "scale.x": 1, "scale.y": 1}, 0.6, {ease: FlxEase.expoOut});

		#if HSCRIPT_ALLOWED
		StateScriptHandler.callOnScripts('postCreate', []);
		#end

		#if mobileC
		addVirtualPad(FULL, A_B);
		#end

		super.create();
	}

	function songsSystem()
	{
		for (i in 0...songInfo.songsWeeks.length)
		{
			addWeek(songInfo.songsWeeks[i].weekSongs, i, songInfo.songsWeeks[i].songIcons);
			coolColors.push(Std.parseInt(songInfo.songsWeeks[i].color[i]));
		}
	}

	function loadSongsData():Void
	{
		#if sys
		// ── Cuando hay un mod activo, solo mostrar las canciones del mod ──────
		if (mods.ModManager.isActive())
		{
			final fmt = mods.compat.ModCompatLayer.getActiveModFormat();

			if (fmt == mods.compat.ModFormat.PSYCH_ENGINE)
			{
				songInfo = { songsWeeks: [] };
				for (modWeek in mods.compat.ModCompatLayer.getModSongsInfo())
				{
					var hideFP:Bool = Reflect.field(modWeek, 'hideFreeplay') == true;
					if (!hideFP)
						songInfo.songsWeeks.push(cast modWeek);
				}
				trace('[FreeplayEditorState] Mod Psych activo "${mods.ModManager.activeMod}" — semanas: ${songInfo.songsWeeks.length}');
			}
			else
			{
				var modSongListPath = '${mods.ModManager.modRoot()}/songs/songList.json';
				var file:String = null;
				if (sys.FileSystem.exists(modSongListPath))
					file = sys.io.File.getContent(modSongListPath);

				if (file != null && file.trim() != '')
				{
					try { songInfo = cast haxe.Json.parse(file); }
					catch (e:Dynamic) { songInfo = null; }
				}

				if (songInfo == null)
				{
					songInfo = _autoDiscoverModSongs();
					if (songInfo != null)
						trace('[FreeplayEditorState] Mod "${mods.ModManager.activeMod}" — canciones auto-descubiertas: ${songInfo.songsWeeks.length} semanas');
				}
			}
			return; // No cargar canciones base
		}
		#end

		// ── Sin mod activo: cargar songList base ──────────────────────────────
		var songListPath:String = Paths.jsonSong('songList');
		var file:String = null;
		#if sys
		if (sys.FileSystem.exists(songListPath))
			file = sys.io.File.getContent(songListPath);
		#end
		if (file == null)
		{
			try { file = lime.utils.Assets.getText(songListPath); } catch (_:Dynamic) {}
		}
		try
		{
			if (file != null && file.trim() != '')
				songInfo = cast haxe.Json.parse(file);
		}
		catch (e:Dynamic)
		{
			trace("Error loading song data for " + songListPath + ": " + e);
			songInfo = null;
		}
	}

	#if sys
	/** Auto-descubre canciones desde la carpeta songs/ del mod activo como una semana única. */
	function _autoDiscoverModSongs():StoryMenuState.Songs
	{
		final modId   = mods.ModManager.activeMod;
		if (modId == null) return null;
		final songsDir = '${mods.ModManager.MODS_FOLDER}/$modId/songs';
		if (!sys.FileSystem.exists(songsDir)) return null;

		var songNames:Array<String> = [];
		var songIcons:Array<String> = [];
		var bpms:Array<Float>       = [];
		for (entry in sys.FileSystem.readDirectory(songsDir))
		{
			final ep = '$songsDir/$entry';
			if (!sys.FileSystem.isDirectory(ep)) continue;
			// Check that a chart file exists
			var hasChart = false;
			for (diff in ['hard', 'normal', 'easy', 'chart'])
				if (sys.FileSystem.exists('$ep/$diff.json')) { hasChart = true; break; }
			if (!hasChart) continue;
			songNames.push(entry);
			songIcons.push('icon-$entry');
			bpms.push(120.0);
		}
		if (songNames.length == 0) return null;

		final modInfo = mods.ModManager.getInfo(modId);
		final colorHex = modInfo != null ? StringTools.hex(modInfo.color & 0xFFFFFF, 6) : 'FF9900';
		return {
			songsWeeks: [{
				weekName:       modInfo != null ? modInfo.name : modId,
				weekSongs:      songNames,
				songIcons:      songIcons,
				color:          [colorHex],
				bpm:            bpms,
				weekCharacters: ['bf', 'gf', 'dad']
			}]
		};
	}
	#end

	override function closeSubState()
	{
		trace('[FreeplayState] Songs loaded: ' + songs.length);
		changeSelection();

		// ✅ FIX: Limpiar inputs residuales al volver de un substate
		// Esto evita que un ENTER usado para salir del pause menu se procese en FreeplayState
		FlxG.keys.reset();

		super.closeSubState();
	}

	public function addSong(songName:String, weekNum:Int, songCharacter:String)
	{
		songs.push(new SongMetadata(songName, weekNum, songCharacter));
	}

	public function addWeek(songs:Array<String>, weekNum:Int, ?songCharacters:Array<String>)
	{
		if (songCharacters == null)
			songCharacters = ['bf'];

		var num:Int = 0;
		for (song in songs)
		{
			addSong(song, weekNum, songCharacters[num]);
			if (songCharacters.length != 1)
				num++;
		}
	}

	public static var vocals:FlxSound = null;
	public static var instPlaying:Int = -1;

	override function update(elapsed:Float)
	{
		#if HSCRIPT_ALLOWED
		StateScriptHandler.callOnScripts('onUpdate', [elapsed]);
		#end

		if (StickerTransition.isActive())
		{
			super.update(elapsed);
			return; // ← CRÍTICO: No procesar inputs durante la transición
		}

		// Actualizar efectos visuales
		updateScreenBump(elapsed);
		updateVisualBars(elapsed);

		// Interpolar score
		lerpScore = Math.floor(FlxMath.lerp(lerpScore, intendedScore, boundTo(elapsed * 24, 0, 1)));
		lerpRating = FlxMath.lerp(lerpRating, intendedRating, boundTo(elapsed * 12, 0, 1));

		if (Math.abs(lerpScore - intendedScore) <= 10)
			lerpScore = intendedScore;
		if (Math.abs(lerpRating - intendedRating) <= 0.01)
			lerpRating = intendedRating;

		scoreText.text = 'PERSONAL BEST: ' + lerpScore;
		positionHighscore();

		var upP = controls.UP_P;
		var downP = controls.DOWN_P;
		var leftP = controls.LEFT_P;
		var rightP = controls.RIGHT_P;
		var accepted = FlxG.keys.justPressed.ENTER;
		var space = FlxG.keys.justPressed.SPACE;

		if (songs.length == 0)
		{
			accepted = false;
			space = false;
		}

		#if HSCRIPT_ALLOWED
		if (upP && !StateScriptHandler.callOnScripts('interceptNav', [-1, 0]))
			changeSelection(-1);
		if (downP && !StateScriptHandler.callOnScripts('interceptNav', [1, 0]))
			changeSelection(1);
		if (leftP && !StateScriptHandler.callOnScripts('interceptNav', [0, -1]))
			changeDiff(-1);
		if (rightP && !StateScriptHandler.callOnScripts('interceptNav', [0, 1]))
			changeDiff(1);
		#else
		if (upP)
			changeSelection(-1);
		if (downP)
			changeSelection(1);
		if (leftP)
			changeDiff(-1);
		if (rightP)
			changeDiff(1);
		#end

		if (controls.BACK)
		{
			FlxG.sound.play(Paths.sound('menus/cancelMenu'));
			StateTransition.switchState(new MainMenuState());
		}

		// Abrir el editor con la tecla E (solo en Developer Mode — Ctrl+D en MainMenu para activarlo)
		if (FlxG.keys.justPressed.E && funkin.menus.MainMenuState.developerMode)
		{
			StateTransition.switchState(new FreeplayEditorState());
		}

		#if cpp
		if (space)
		{
			if (instPlaying != curSelected)
			{
				destroyFreeplayVocals();
				FlxG.sound.music.volume = 0;

				var songLowercase:String = songs[curSelected].songName.toLowerCase();
				var poop:String = Highscore.formatSong(songLowercase, curDifficulty);

				// Verify if JSON exists before trying to preview
				var jsonExists:Bool = Song.findChart(songLowercase, poop) != null;

				if (!jsonExists)
				{
					// Show error message
					showError('Cannot preview: Chart file not found!\n"$poop.json" is missing');
					FlxG.sound.play(Paths.sound('menus/cancelMenu'));
					return;
				}

				// Try to load JSON
				try
				{
					PlayState.SONG = Song.loadFromJson(poop, songLowercase);

					if (PlayState.SONG == null || PlayState.SONG.song == null)
					{
						showError('Cannot preview: Chart file is corrupted!');
						FlxG.sound.play(Paths.sound('menus/cancelMenu'));
						return;
					}
				}
				catch (e:Dynamic)
				{
					showError('Cannot preview: Failed to load chart!');
					FlxG.sound.play(Paths.sound('menus/cancelMenu'));
					trace('Error loading song JSON for preview: ' + e);
					return;
				}

				// Cargar voces usando el método seguro
				final diffSuffix:String = difficultyStuff.length > curDifficulty ? difficultyStuff[curDifficulty][1] : '';
				if (PlayState.SONG.needsVoices)
					vocals = Paths.loadVoices(PlayState.SONG.song, diffSuffix);
				else
					vocals = new FlxSound();

				FlxG.sound.list.add(vocals);

				// Cargar instrumental usando el método seguro
				FlxG.sound.music = Paths.loadInst(PlayState.SONG.song, diffSuffix);
				FlxG.sound.music.persist = true;
				FlxG.sound.music.looped = true;
				FlxG.sound.music.volume = 0.7;
				FlxG.sound.music.play();

				vocals.persist = true;
				vocals.looped = true;
				vocals.volume = 0.7;
				vocals.play();
				instPlaying = curSelected;

				// Establecer BPM para el screen bump
				if (songInfo != null && songInfo.songsWeeks.length > curSelected)
				{
					var weekIndex = songs[curSelected].week;
					if (weekIndex < songInfo.songsWeeks.length
						&& songInfo.songsWeeks[weekIndex].bpm != null
						&& songInfo.songsWeeks[weekIndex].bpm.length > 0)
					{
						bpmTarget = songInfo.songsWeeks[weekIndex].bpm[0];
					}
				}

				Conductor.changeBPM(bpmTarget);

				if (discSpr != null)
				{
					remove(discSpr);
					discSpr.destroy();
				}

				discSpr = new FlxSprite(750, 280);
				discSpr.frames = Paths.getSparrowAtlas('freeplay/record player freeplay');
				discSpr.antialiasing = FlxG.save.data.antialiasing;
				discSpr.animation.addByPrefix('idle', 'disco', 24);
				discSpr.animation.play('idle');
				discSpr.x += 750;
				discSpr.setGraphicSize(Std.int(discSpr.width * 0.5));
				discSpr.updateHitbox();
				add(discSpr);

				FlxTween.tween(discSpr, {"x": 750}, 0.6, {ease: FlxEase.elasticInOut});

				// Efecto de glow al reproducir
				FlxTween.tween(glowOverlay, {alpha: 0.15}, 0.2, {
					ease: FlxEase.quadOut,
					onComplete: function(twn:FlxTween)
					{
						FlxTween.tween(glowOverlay, {alpha: 0}, 0.4, {ease: FlxEase.quadIn});
					}
				});
			}
			else
			{
				destroyFreeplayVocals();
				final gfSnd = Paths.loadMusic('girlfriendsRingtone/girlfriendsRingtone');
				if (gfSnd != null) FlxG.sound.playMusic(gfSnd, 0.7);
				else FlxG.sound.playMusic(Paths.music('girlfriendsRingtone/girlfriendsRingtone'), 0.7);
				instPlaying = -1;

				if (discSpr != null)
				{
					FlxTween.tween(discSpr, {"x": discSpr.x + 750}, 0.6, {
						ease: FlxEase.elasticInOut,
						onComplete: function(twn:FlxTween)
						{
							if (discSpr != null)
							{
								remove(discSpr);
								discSpr.destroy();
								discSpr = null;
							}
						}
					});
				}
			}
		}
		#end

		if (accepted)
		{
			#if HSCRIPT_ALLOWED
			var cancelled = StateScriptHandler.callOnScriptsReturn('onAccept', [], false);
			if (cancelled)
				return;
			#end

			var songLowercase:String = songs[curSelected].songName.toLowerCase();
			var poop:String = Highscore.formatSong(songLowercase, curDifficulty);
			trace('[FreeplayState] Attempting to load song: $songLowercase');
			trace('[FreeplayState] Formatted filename: $poop');
			trace('[FreeplayState] Current difficulty: $curDifficulty');

			// Verify if JSON exists
			var jsonExists:Bool = Song.findChart(songLowercase, poop) != null;
			trace('[FreeplayState] findChart($songLowercase, $poop) = $jsonExists');

			if (!jsonExists)
			{
				// Show error message
				trace('[FreeplayState] ERROR: JSON not found!');
				showError('ERROR: Chart file not found!\n"$poop.json" is missing');
				FlxG.sound.play(Paths.sound('menus/cancelMenu'));
				FlxG.camera.shake(0.01, 0.3);
				return;
			}

			// Try to load JSON
			try
			{
				trace('[FreeplayState] Attempting to load JSON...');
				PlayState.SONG = Song.loadFromJson(poop, songLowercase);
				trace('[FreeplayState] JSON loaded successfully');

				// Validate song data
				if (PlayState.SONG == null || PlayState.SONG.song == null)
				{
					trace('[FreeplayState] ERROR: Song data is null or corrupted');
					showError('ERROR: Chart file is corrupted!\nPlease check "$poop.json"');
					FlxG.sound.play(Paths.sound('menus/cancelMenu'));
					FlxG.camera.shake(0.01, 0.3);
					return;
				}

				trace('[FreeplayState] Song name in JSON: ${PlayState.SONG.song}');
			}
			catch (e:Dynamic)
			{
				// Show error message on load failure
				trace('[FreeplayState] ERROR loading JSON: $e');
				showError('ERROR: Failed to load chart!\n' + e);
				FlxG.sound.play(Paths.sound('menus/cancelMenu'));
				FlxG.camera.shake(0.01, 0.3);
				return;
			}

			trace('[FreeplayState] All validations passed, loading PlayState...');
			PlayState.isStoryMode = false;
			PlayState.storyDifficulty = curDifficulty;

			PlayState.storyWeek = songs[curSelected].week;
			trace('CURRENT WEEK: ' + getCurrentWeekNumber());
			if (colorTween != null)
			{
				colorTween.cancel();
			}
			FlxG.sound.music.volume = 0;

			if (FlxG.save.data.flashing)
				FlxG.camera.flash(FlxColor.WHITE, 1);
			FlxG.sound.play(Paths.sound('menus/confirmMenu'), 0.7);

			StickerTransition.start(function()
			{
				LoadingState.loadAndSwitchState(new PlayState());
			});

			destroyFreeplayVocals();
		}

		super.update(elapsed);

		#if HSCRIPT_ALLOWED
		StateScriptHandler.callOnScripts('onUpdatePost', [elapsed]);
		#end
	}

	// === FUNCIÓN PARA SCREEN BUMP AL RITMO ===
	function updateScreenBump(elapsed:Float):Void
	{
		if (FlxG.sound.music != null && FlxG.sound.music.playing)
		{
			var curBPM:Float = bpmTarget > 0 ? bpmTarget : 102; // BPM por defecto
			var songPos:Float = Conductor.songPosition;

			beatTimer += elapsed * 1000;

			var calculatedBeat:Int = Math.floor((songPos / 1000) * (curBPM / 60));

			if (calculatedBeat != lastScreenBumpBeat && calculatedBeat % 1 == 0)
			{
				lastScreenBumpBeat = calculatedBeat;
				screenBump();

				// Bump de iconos cada 4 beats
				if (calculatedBeat % 4 == 0)
				{
					for (icon in iconArray)
					{
						if (icon != null && icon.scale != null)
						{
							icon.scale.set(1.3, 1.3);
							FlxTween.tween(icon.scale, {x: 1, y: 1}, 0.2, {ease: FlxEase.expoOut});
						}
					}
				}
			}
		}

		// Suavizar el zoom de vuelta
		FlxG.camera.zoom = FlxMath.lerp(FlxG.camera.zoom, 1, elapsed * 3);
	}

	// === BUMP DE PANTALLA ===
	function screenBump():Void
	{
		FlxG.camera.zoom += 0.015 * camBumpIntensity;

		// Pequeño shake
		FlxG.camera.shake(0.002, 0.05);

		// Pulse en el glow overlay
		if (glowOverlay != null)
		{
			glowOverlay.alpha = 0.05;
			FlxTween.tween(glowOverlay, {alpha: 0}, 0.3, {ease: FlxEase.quadOut});
		}
	}

	// === ACTUALIZAR BARRAS VISUALES ===
	function updateVisualBars(elapsed:Float):Void
	{
		var i:Int = 0;
		for (bar in visualBars)
		{
			if (bar != null && bar.scale != null)
			{
				var targetHeight:Float = 50 + Math.sin((beatTimer / 100) + i) * 40;
				bar.scale.y = FlxMath.lerp(bar.scale.y, targetHeight / 100, elapsed * 8);
				bar.y = FlxG.height - 150 + 100 - (bar.scale.y * 150);
			}
			i++;
		}
	}

	public static function destroyFreeplayVocals()
	{
		if (vocals != null)
		{
			vocals.stop();
			vocals.destroy();
		}
		vocals = null;
	}

	/**
	 * Detecta las dificultades disponibles para la canción actualmente
	 * seleccionada y actualiza difficultyStuff. Si curDifficulty queda
	 * fuera de rango después del cambio, se ajusta al índice válido más cercano.
	 */
	function _updateDifficultyStuff():Void
	{
		if (songs == null || songs.length == 0) return;
		final songName = songs[curSelected].songName.toLowerCase();
		difficultyStuff = cast Song.getAvailableDifficulties(songName);

		// Clamp curDifficulty al nuevo rango
		if (curDifficulty >= difficultyStuff.length)
			curDifficulty = difficultyStuff.length - 1;
		if (curDifficulty < 0)
			curDifficulty = 0;
	}

	function changeDiff(change:Int = 0)
	{
		if (songs.length == 0) return;

		curDifficulty += change;

		if (curDifficulty < 0)
			curDifficulty = difficultyStuff.length - 1;
		if (curDifficulty >= difficultyStuff.length)
			curDifficulty = 0;

		#if !switch
		intendedScore = Highscore.getScore(songs[curSelected].songName, curDifficulty);
		intendedRating = Highscore.getRating(songs[curSelected].songName, curDifficulty);
		#end

		PlayState.storyDifficulty = curDifficulty;
		diffText.text = '< ' + CoolUtil.difficultyString() + ' >';
		positionHighscore();

		#if HSCRIPT_ALLOWED
		StateScriptHandler.callOnScripts('onDifficultyChanged', [curDifficulty]);
		#end
	}

	function changeSelection(change:Int = 0)
	{
		if (songs.length == 0) return;

		FlxG.sound.play(Paths.sound('menus/scrollMenu'), 0.4);

		curSelected += change;

		if (curSelected < 0)
			curSelected = songs.length - 1;
		if (curSelected >= songs.length)
			curSelected = 0;

		var newColor:Int = songs[curSelected].color;
		if (newColor != intendedColor)
		{
			if (colorTween != null)
			{
				colorTween.cancel();
			}
			intendedColor = newColor;
			colorTween = FlxTween.color(bg, 1, bg.color, intendedColor, {
				onComplete: function(twn:FlxTween)
				{
					colorTween = null;
				}
			});
		}

		#if !switch
		intendedScore = Highscore.getScore(songs[curSelected].songName, curDifficulty);
		intendedRating = Highscore.getRating(songs[curSelected].songName, curDifficulty);
		#end

		var bullShit:Int = 0;

		for (i in 0...iconArray.length)
		{
			if (iconArray[i] != null)
				iconArray[i].alpha = 0.6;
		}

		if (iconArray[curSelected] != null)
			iconArray[curSelected].alpha = 1;

		for (item in grpSongs.members)
		{
			if (item != null)
			{
				item.targetY = bullShit - curSelected;
				bullShit++;

				item.alpha = 0.6;

				if (item.targetY == 0)
				{
					item.alpha = 1;

					// Efecto de pulse en la canción seleccionada
					FlxTween.cancelTweensOf(item.scale);
					item.scale.set(1.05, 1.05);
					FlxTween.tween(item.scale, {x: 1, y: 1}, 0.3, {ease: FlxEase.expoOut});
				}
			}
		}

		// Auto-detectar las dificultades disponibles para la canción seleccionada
		_updateDifficultyStuff();

		// Pequeño bump al cambiar selección
		FlxG.camera.zoom = 1.02;

		changeDiff();

		#if HSCRIPT_ALLOWED
		StateScriptHandler.callOnScripts('onSelectionChanged', [curSelected]);
		StateScriptHandler.callOnScripts('onSongSelected', [songs[curSelected].songName]);
		#end
	}

	private function positionHighscore()
	{
		scoreText.x = FlxG.width - scoreText.width - 20;

		scoreBG.scale.x = FlxG.width - scoreText.x + 16;
		scoreBG.x = FlxG.width - (scoreBG.scale.x / 2);
		diffText.x = Std.int(scoreBG.x + (scoreBG.width / 2));
		diffText.x -= diffText.width / 2;
	}

	public static var difficultyStuff:Array<Dynamic> = [['Easy', '-easy'], ['Normal', ''], ['Hard', '-hard']];

	public static function boundTo(value:Float, min:Float, max:Float):Float
	{
		var newValue:Float = value;
		if (newValue < min)
			newValue = min;
		else if (newValue > max)
			newValue = max;
		return newValue;
	}

	public static function getCurrentWeekNumber():Int
	{
		return getWeekNumber(PlayState.storyWeek);
	}

	public static function getWeekNumber(num:Int):Int
	{
		var value:Int = 0;
		var weekNumber:Int = 0;

		if (songInfo != null && songInfo.songsWeeks != null)
			weekNumber = songInfo.songsWeeks.length;

		if (num < weekNumber)
		{
			value = num;
		}

		return value;
	}

	function showError(message:String):Void
	{
		// Cancel any existing error tween
		if (errorTween != null)
		{
			errorTween.cancel();
		}

		// Set error message
		errorText.text = message;
		errorText.visible = true;
		errorText.alpha = 0;

		// Fade in
		errorTween = FlxTween.tween(errorText, {alpha: 1}, 0.3, {
			ease: FlxEase.expoOut,
			onComplete: function(twn:FlxTween)
			{
				// Wait 3 seconds then fade out
				errorTween = FlxTween.tween(errorText, {alpha: 0}, 0.5, {
					ease: FlxEase.expoIn,
					startDelay: 3.0,
					onComplete: function(twn:FlxTween)
					{
						errorText.visible = false;
					}
				});
			}
		});
	}

	/**
	 * Llamado cuando el juego pierde foco (minimizar ventana)
	 * Pausa las vocals para que estén sincronizadas con el instrumental
	 */
	override public function onFocusLost():Void
	{
		super.onFocusLost();

		// Pausar vocals cuando se pierde foco
		if (vocals != null && vocals.playing)
		{
			vocals.pause();
			trace('[FreeplayState] Focus lost - vocals paused');
		}

		// FlxG.sound.music se pausa automáticamente
		trace('[FreeplayState] Focus lost - music will be paused by FlxG');
	}

	/**
	 * Llamado cuando el juego recupera foco (volver a la ventana)
	 * Reanuda TANTO el instrumental como las vocals
	 */
	override public function onFocus():Void
	{
		super.onFocus();

		// CRÍTICO: Con loadStream(), FlxG.sound.music NO se reanuda automáticamente
		// Necesitamos reanudarlo manualmente si hay una preview sonando
		if (FlxG.sound.music != null && instPlaying == curSelected)
		{
			// Reanudar el instrumental
			FlxG.sound.music.play();
			trace('[FreeplayState] Focus gained - music resumed');

			// Reanudar vocals sincronizadas con el instrumental
			if (vocals != null)
			{
				vocals.time = FlxG.sound.music.time;
				vocals.play();
				trace('[FreeplayState] Focus gained - vocals resumed and resynced');
			}
		}
	}

	override function destroy()
	{
		#if HSCRIPT_ALLOWED
		StateScriptHandler.callOnScripts('onDestroy', []);
		StateScriptHandler.clearStateScripts();
		#end

		super.destroy();
	}
}

class SongMetadata
{
	public var songName:String = "";
	public var week:Int = 0;
	public var songCharacter:String = "";
	public var color:Int = -7179779;

	public function new(song:String, week:Int, songCharacter:String)
	{
		this.songName = song;
		this.week = week;
		this.songCharacter = songCharacter;
		if (week < funkin.menus.FreeplayState.coolColors.length)
		{
			this.color = funkin.menus.FreeplayState.coolColors[week];
		}
	}
}
